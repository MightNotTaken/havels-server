If you want customize **/setup** webpage (headers, logo etc etc):
* edit the source files as your needs (setup.htm, app.js, style.css)
* open a terminal in *build* folder and run `npm i` to install all nodejs modules needed
* run `node minimize.js`
* overwrite the content of *setup_htm.h* in src folder with the new generated file
