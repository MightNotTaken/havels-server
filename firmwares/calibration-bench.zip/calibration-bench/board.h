#ifndef BOARD_H__
#define BOARD_H__
#define PULSE_SOURCE_0               19
#define PULSE_SOURCE_1               21
#define PULSE_SOURCE_2               22
#endif